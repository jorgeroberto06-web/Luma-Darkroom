# Luma Darkroom 1.1.0 — proyecto para Codex

Editor fotográfico local para Windows. Esta actualización añade un mezclador de color selectivo basado en una tríada cromática.

## Novedades frente a 1.0

- **Mezclador de color · tríada:** elige o toma un color de la foto y Luma propone dos tonos separados por 120° y 240°.
- **Control por rango:** ajusta luz, saturación e intensidad de cada uno de los tres colores.
- **Atenuar otros colores:** reduce tonos fuera de la tríada para dar más protagonismo al color elegido.
- Los ajustes se reflejan en la vista previa y en la exportación JPEG.

## Funciones que conserva

- Revelado de archivos RAW Panasonic **.RW2**.
- Máscaras locales con marcador rojo durante la selección y vista de los ajustes al editar.
- Zoom preciso con la tecla **Z** y el mouse; desplazamiento con la **barra espaciadora**.
- Focus stacking con alineación y unión de las áreas más enfocadas.
- Procesamiento local de las fotografías.

## Abrir en Codex

1. Descomprime `Luma-Darkroom-Codex-v1.1.0.zip`.
2. Abre la carpeta `Luma-Darkroom-Codex` como proyecto.
3. En una terminal dentro de esa carpeta, ejecuta `npm install`.
4. Para iniciar la app web local: `npm run dev`.
5. Para iniciar la app de escritorio: `npm run desktop:dev`.

## Crear instalador de Windows

Consulta `DESKTOP-WINDOWS.md` y ejecuta `./scripts/build-windows.ps1` en PowerShell. Se requieren Windows 10/11, Node.js LTS, Rust MSVC, Microsoft C++ Build Tools y WebView2.

La edición RAW actual decodifica a RGBA de 8 bits y la exportación final está limitada a JPEG. La compatibilidad RAW se centra por ahora en Panasonic RW2.
