$ErrorActionPreference = 'Stop'

if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw 'Node.js no está instalado. Instala Node.js LTS y vuelve a ejecutar este script.'
}
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
  throw 'npm no está disponible en PATH.'
}
if (-not (Get-Command rustc -ErrorAction SilentlyContinue) -or -not (Get-Command cargo -ErrorAction SilentlyContinue)) {
  throw 'Rust no está instalado. Instala Rust MSVC con rustup y vuelve a ejecutar este script.'
}

$root = Split-Path -Parent $PSScriptRoot
Push-Location $root
try {
  npm install
  if ($LASTEXITCODE -ne 0) { throw 'Falló npm install.' }
  npm run desktop:build
  if ($LASTEXITCODE -ne 0) { throw 'Falló la compilación de escritorio.' }
  Write-Host "Instaladores generados en: $root\src-tauri\target\release\bundle"
}
finally {
  Pop-Location
}
