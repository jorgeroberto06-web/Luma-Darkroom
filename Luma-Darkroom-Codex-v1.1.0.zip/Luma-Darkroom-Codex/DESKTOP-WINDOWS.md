# Luma Darkroom para Windows (versión inicial)

Esta carpeta añade una envoltura de escritorio Tauri al editor web existente. La primera versión está orientada a Windows y conserva el editor actual, incluyendo la carga RAW RW2 mediante FlashRaw/WebAssembly.

## Requisitos para compilar en Windows

1. Windows 10 u 11 de 64 bits.
2. Node.js LTS.
3. Rust con la cadena `stable-msvc`.
4. Microsoft C++ Build Tools con **Desktop development with C++**.
5. Microsoft Edge WebView2 Runtime.

Tauri usa WebView2 para renderizar la interfaz en Windows. El instalador puede generarse como `.msi` y como ejecutable NSIS.

## Crear los instaladores

Abre PowerShell en la carpeta del proyecto y ejecuta:

```powershell
.\scripts\build-windows.ps1
```

Los archivos resultantes aparecerán en `src-tauri\target\release\bundle`.

## Lo que incluye este primer paso

- Ventana de escritorio con apertura de imágenes y RAW desde un diálogo del sistema.
- Exportación JPEG mediante diálogo Guardar como.
- La web y la aplicación de escritorio comparten el mismo editor y los mismos recursos RAW.
- Los archivos se procesan localmente; la aplicación no sube las fotografías a un servidor.

El proyecto editable, gestión de sesiones y una ruta RAW de 16 bits se incorporarán en etapas posteriores. La edición RAW actual decodifica a RGBA de 8 bits y la exportación final está limitada a JPEG.
