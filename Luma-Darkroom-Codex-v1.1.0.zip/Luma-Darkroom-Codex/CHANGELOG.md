# Cambios de Luma Darkroom

## 1.1.0
- Añade mezclador selectivo de color en tríada (tono principal y dos complementarios a 120° y 240°).
- Añade controles independientes de luz, saturación e intensidad para cada tono.
- Añade atenuación de colores fuera de la tríada.
- Conserva revelado Panasonic RW2, máscaras locales, zoom y paneo, y focus stacking de la 1.0.
