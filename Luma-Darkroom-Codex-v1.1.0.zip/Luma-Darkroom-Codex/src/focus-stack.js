const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
const yieldToUI = () => new Promise((resolve) => setTimeout(resolve, 0));

function makeGrayPreview(source, width, height, maxSide = 192) {
  const scale = Math.min(1, maxSide / Math.max(width, height));
  const w = Math.max(48, Math.round(width * scale));
  const h = Math.max(48, Math.round(height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(source, 0, 0, w, h);
  const rgba = ctx.getImageData(0, 0, w, h).data;
  const gray = new Float32Array(w * h);
  for (let i = 0, p = 0; i < gray.length; i++, p += 4) {
    gray[i] = rgba[p] * 0.299 + rgba[p + 1] * 0.587 + rgba[p + 2] * 0.114;
  }
  canvas.width = canvas.height = 0;
  return { gray, width: w, height: h };
}

function sample(gray, width, height, x, y) {
  if (x < 1 || y < 1 || x >= width - 2 || y >= height - 2) return null;
  const x0 = Math.floor(x), y0 = Math.floor(y), fx = x - x0, fy = y - y0;
  const i = y0 * width + x0;
  const a = gray[i] * (1 - fx) + gray[i + 1] * fx;
  const b = gray[i + width] * (1 - fx) + gray[i + width + 1] * fx;
  return a * (1 - fy) + b * fy;
}

function alignmentScore(reference, moving, transform, step) {
  const { width: w, height: h } = reference;
  const { scale, angle, dx, dy } = transform;
  const cs = Math.cos(angle), sn = Math.sin(angle), cx = w / 2, cy = h / 2;
  let dot = 0, refPower = 0, movPower = 0, count = 0;
  for (let y = 18; y < h - 18; y += step) {
    for (let x = 18; x < w - 18; x += step) {
      const rx = reference.gray[y * w + x + 1] - reference.gray[y * w + x - 1];
      const ry = reference.gray[(y + 1) * w + x] - reference.gray[(y - 1) * w + x];
      const px = (x - cx - dx), py = (y - cy - dy);
      const sx = (cs * px + sn * py) / scale + cx;
      const sy = (-sn * px + cs * py) / scale + cy;
      const ml = sample(moving.gray, w, h, sx - 1, sy);
      const mr = sample(moving.gray, w, h, sx + 1, sy);
      const mu = sample(moving.gray, w, h, sx, sy - 1);
      const md = sample(moving.gray, w, h, sx, sy + 1);
      if (ml === null || mr === null || mu === null || md === null) continue;
      const mx = mr - ml, my = md - mu;
      dot += rx * mx + ry * my;
      refPower += rx * rx + ry * ry;
      movPower += mx * mx + my * my;
      count++;
    }
  }
  if (count < 100 || refPower < 1 || movPower < 1) return -1;
  return dot / Math.sqrt(refPower * movPower);
}

function estimateAlignment(reference, moving) {
  const center = { scale: 1, angle: 0, dx: 0, dy: 0 };
  let best = { ...center, score: alignmentScore(reference, moving, center, 6) };
  for (const scale of [0.96, 0.98, 1, 1.02, 1.04]) {
    for (const degrees of [-2, -1, 0, 1, 2]) {
      for (const dx of [-8, -4, 0, 4, 8]) {
        for (const dy of [-8, -4, 0, 4, 8]) {
          const candidate = { scale, angle: degrees * Math.PI / 180, dx, dy };
          const score = alignmentScore(reference, moving, candidate, 6);
          if (score > best.score) best = { ...candidate, score };
        }
      }
    }
  }
  const coarse = { ...best };
  for (let si = -2; si <= 2; si++) {
    for (let ai = -2; ai <= 2; ai++) {
      for (let dx = -3; dx <= 3; dx++) {
        for (let dy = -3; dy <= 3; dy++) {
          const candidate = {
            scale: clamp(coarse.scale + si * 0.01, 0.9, 1.1),
            angle: coarse.angle + ai * (0.5 * Math.PI / 180),
            dx: coarse.dx + dx,
            dy: coarse.dy + dy,
          };
          const score = alignmentScore(reference, moving, candidate, 4);
          if (score > best.score) best = { ...candidate, score };
        }
      }
    }
  }
  return best;
}

async function makeSharpnessMap(canvas, width, height, mapWidth, mapHeight) {
  const small = document.createElement('canvas');
  small.width = mapWidth;
  small.height = mapHeight;
  const ctx = small.getContext('2d', { willReadFrequently: true });
  ctx.drawImage(canvas, 0, 0, mapWidth, mapHeight);
  const rgba = ctx.getImageData(0, 0, mapWidth, mapHeight).data;
  small.width = small.height = 0;
  const gray = new Float32Array(mapWidth * mapHeight);
  for (let i = 0, p = 0; i < gray.length; i++, p += 4) {
    gray[i] = rgba[p] * 0.299 + rgba[p + 1] * 0.587 + rgba[p + 2] * 0.114;
  }
  const scores = new Float32Array(gray.length);
  for (let y = 1; y < mapHeight - 1; y++) {
    for (let x = 1; x < mapWidth - 1; x++) {
      const i = y * mapWidth + x;
      const left = gray[i - 1], right = gray[i + 1], up = gray[i - mapWidth], down = gray[i + mapWidth];
      const laplacian = Math.abs(4 * gray[i] - left - right - up - down);
      const gradient = Math.abs(right - left) + Math.abs(down - up);
      scores[i] = laplacian + gradient * 0.15;
    }
  }
  // Blur the local sharpness estimates so the focus mask follows regions rather than pixel noise.
  const radius = 4, temp = new Float32Array(scores.length);
  for (let y = 0; y < mapHeight; y++) {
    let sum = 0;
    for (let x = -radius; x <= radius; x++) if (x >= 0 && x < mapWidth) sum += scores[y * mapWidth + x];
    for (let x = 0; x < mapWidth; x++) {
      const count = Math.min(mapWidth - 1, x + radius) - Math.max(0, x - radius) + 1;
      temp[y * mapWidth + x] = sum / count;
      const left = x - radius, right = x + radius + 1;
      if (left >= 0) sum -= scores[y * mapWidth + left];
      if (right < mapWidth) sum += scores[y * mapWidth + right];
    }
  }
  for (let x = 0; x < mapWidth; x++) {
    let sum = 0;
    for (let y = -radius; y <= radius; y++) if (y >= 0 && y < mapHeight) sum += temp[y * mapWidth + x];
    for (let y = 0; y < mapHeight; y++) {
      const count = Math.min(mapHeight - 1, y + radius) - Math.max(0, y - radius) + 1;
      scores[y * mapWidth + x] = sum / count;
      const top = y - radius, bottom = y + radius + 1;
      if (top >= 0) sum -= temp[top * mapWidth + x];
      if (bottom < mapHeight) sum += temp[bottom * mapWidth + x];
    }
  }
  return scores;
}

function selectTopFocusFrames(scoreMaps, pixelCount) {
  const ids = new Uint8Array(pixelCount * 4);
  const weights = new Float32Array(pixelCount * 4);
  for (let p = 0; p < pixelCount; p++) {
    let max = 0;
    for (let f = 0; f < scoreMaps.length; f++) if (scoreMaps[f][p] > max) max = scoreMaps[f][p];
    if (max < 8) {
      ids[p * 4] = 0;
      weights[p * 4] = 1;
      continue;
    }
    let sum = 0, bestIds = [-1, -1, -1, -1], bestWeights = [0, 0, 0, 0];
    for (let f = 0; f < scoreMaps.length; f++) {
      const score = Math.pow(scoreMaps[f][p] / max, 8);
      sum += score;
      for (let slot = 0; slot < 4; slot++) {
        if (score > bestWeights[slot]) {
          for (let j = 3; j > slot; j--) { bestWeights[j] = bestWeights[j - 1]; bestIds[j] = bestIds[j - 1]; }
          bestWeights[slot] = score; bestIds[slot] = f; break;
        }
      }
    }
    let selected = bestWeights.reduce((a, b) => a + b, 0);
    if (!selected) { bestIds[0] = 0; bestWeights[0] = selected = 1; sum = 1; }
    for (let slot = 0; slot < 4; slot++) {
      ids[p * 4 + slot] = bestIds[slot] < 0 ? bestIds[0] : bestIds[slot];
      weights[p * 4 + slot] = bestWeights[slot] / selected;
    }
  }
  return { ids, weights };
}

export async function runFocusStack(frames, onProgress = () => {}) {
  if (!Array.isArray(frames) || frames.length < 2) throw new Error('Selecciona al menos dos imágenes para apilar.');
  const width = frames[0].width, height = frames[0].height;
  const totalPixels = frames.reduce((sum, frame) => sum + frame.width * frame.height, 0);
  if (totalPixels > 540_000_000) {
    throw new Error('El apilado supera el límite seguro de memoria para este equipo. Prueba con menos tomas o imágenes reducidas.');
  }
  const reference = makeGrayPreview(frames[0], width, height);
  const referenceCanvas = frames[0];
  const aligned = [referenceCanvas];
  const transforms = [{ scale: 1, angle: 0, dx: 0, dy: 0, score: 1 }];
  for (let i = 1; i < frames.length; i++) {
    onProgress({ phase: 'align', current: i + 1, total: frames.length });
    const preview = makeGrayPreview(frames[i], width, height);
    const transform = estimateAlignment(reference, preview);
    preview.gray = null;
    const output = document.createElement('canvas');
    output.width = width;
    output.height = height;
    const ctx = output.getContext('2d');
    const cx = width / 2, cy = height / 2;
    const dx = transform.dx * width / reference.width;
    const dy = transform.dy * height / reference.height;
    const c = Math.cos(transform.angle) * transform.scale;
    const s = Math.sin(transform.angle) * transform.scale;
    ctx.setTransform(c, s, -s, c, cx + dx - c * cx + s * cy, cy + dy - s * cx - c * cy);
    ctx.drawImage(frames[i], 0, 0, width, height);
    aligned.push(output);
    transforms.push(transform);
    frames[i].width = frames[i].height = 0;
    await yieldToUI();
  }
  reference.gray = null;

  const mapWidth = Math.min(1200, width);
  const mapHeight = Math.max(1, Math.round(height * mapWidth / width));
  const scoreMaps = [];
  for (let i = 0; i < aligned.length; i++) {
    onProgress({ phase: 'focus', current: i + 1, total: aligned.length });
    scoreMaps.push(await makeSharpnessMap(aligned[i], width, height, mapWidth, mapHeight));
    await yieldToUI();
  }
  onProgress({ phase: 'weights', current: 1, total: 1 });
  const { ids, weights } = selectTopFocusFrames(scoreMaps, mapWidth * mapHeight);
  scoreMaps.length = 0;
  const output = document.createElement('canvas');
  output.width = width;
  output.height = height;
  const outCtx = output.getContext('2d');
  const frameContexts = aligned.map((canvas) => canvas.getContext('2d', { willReadFrequently: true }));
  const bandHeight = 16;
  for (let y = 0; y < height; y += bandHeight) {
    onProgress({ phase: 'merge', current: Math.min(y + bandHeight, height), total: height });
    const h = Math.min(bandHeight, height - y);
    const band = frameContexts.map((ctx) => ctx.getImageData(0, y, width, h));
    const result = new ImageData(width, h);
    const dst = result.data;
    for (let by = 0; by < h; by++) {
      const my = Math.min(mapHeight - 1, Math.floor((y + by) * mapHeight / height));
      for (let x = 0; x < width; x++) {
        const mx = Math.min(mapWidth - 1, Math.floor(x * mapWidth / width));
        const m = (my * mapWidth + mx) * 4;
        const p = (by * width + x) * 4;
        let r = 0, g = 0, b = 0;
        for (let slot = 0; slot < 4; slot++) {
          const weight = weights[m + slot];
          if (weight < 0.002) continue;
          const source = band[ids[m + slot]].data;
          r += source[p] * weight;
          g += source[p + 1] * weight;
          b += source[p + 2] * weight;
        }
        dst[p] = r; dst[p + 1] = g; dst[p + 2] = b; dst[p + 3] = 255;
      }
    }
    outCtx.putImageData(result, 0, y);
    await yieldToUI();
  }
  aligned.forEach((canvas) => { canvas.width = canvas.height = 0; });
  return { image: output, transforms };
}
